/* 
  --- TAREA por SUSPENSIONES OFICIALES y ausencia del profesor en la primer semana de mayo.

--> Para resolver la siguiente tarea, debe ver el video que en canal tiene como título:
	Leer números enteros a un ARREGLO e imprimir sus valores en C
	ENLACE: https://youtu.be/VUmNfYtumuw	

	Hacer un programa que:

	a) Lea el encabezado de una imagen PPM
		Un ejemplo de encabezado es:  
						P3
						50 46
						255

	b) Crear TRES arreglos de números enteros en donde el tamaño de cada uno de los arreglos resulta de multiplicar el ancho por el alto de la imagen.
		Por ejemplo en los datos del inciso a) el ancho de la imagen es 50 y el alto de la imagen es 46, el tamaño resultante de cada uno de los arreglos debe ser de 2300 elementos, el programa debe calcular dicho valor para poder crear los arreglos.

	c) Leer los datos del archivo que se llama tarea.dat de tres en tres y almacenar (guardar) en el orden en que se leen los datos en el orden en que se crearon los arreglos de valores enteros.
	Por ejemplo el archivo tarea.dat contiene el primer renglon de datos como: 
	253 253 253 253 253 253 253 253 253 252 252 252 253 253 253 252 252 252 

	El primer valor 253 se debe almacenar en la primer posición del primer arreglo que se declaró en el programa, el segundo 253 debe guardarse en la primer posición del segundo arreglo que se creó en el programa y el tercer 253 guardarlo en la primer posición del tercer arreglo declarado en el programa. El cuarto 253 se guardará en la segunda posición del primer arreglo declarado, el quinto 253 en la segunda posición del segundo arreglo declarado y el sexto 253 se debe guardar en la segunda posición del tercer arreglo que se creó en el programa. Continuar sucesivamente con la lectura y almacenamiento de los valores enteros en los arreglos leyendo de 3 valores en 3 hasta el tamaño del arreglo.

	d) Imprimir las variables del encabezado de la imagen, de tal forma que se observe como en el siguiente ejemplo:
		P3
		50 46
		255

	e) Imprimir los valores de los 3 arreglos a partir del último elemento almacenado en el arreglo hasta el primer elemento que corresponde al índice 0. Debe ir imprimiendo de 3 en 3 valores.



	f) Ejecutar su programa de la siguiente forma:

		./a.out	< tarea.dat > resultado.ppm; eog resultado.ppm

	g) Enviar por correo electrónico el programa y el resultado.ppm al profesor.

*/
